package com.sample.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyManagementSystemBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
