package com.sample.pms;

public class VendorPolicyServiceTest {

}
