package com.sample.pms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.sample.pms.service.MyUserDetailsService;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	private MyUserDetailsService myUserDetailsService;

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth
//		.inMemoryAuthentication()
//		.passwordEncoder(getPasswordEncoder())
//		.withUser("Kajal@gmail.com").password(getPasswordEncoder().encode("Kajal123")).authorities("EMPLOYEE")
//		.and()
//		.withUser("ninad@gmail.com").password(getPasswordEncoder().encode("ninad@123")).authorities("CUSTOMER")
//		.and()
//		.withUser("albus@gmail.com").password(getPasswordEncoder().encode("albus@123")).authorities("ADMIN");
		
		auth.authenticationProvider(customProvider());

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
		.antMatchers(HttpMethod.PUT, "/api/vendor/status/{status}/{id}").hasAuthority("ADMIN")
		.antMatchers(HttpMethod.GET, "/api/user/login").authenticated()
		.antMatchers(HttpMethod.POST,"/api/vendor/add/{id}").hasAuthority("ADMIN")
		.anyRequest()
		.permitAll()
		.and()
		.httpBasic().and().csrf().disable();
	}

	@Bean
	public PasswordEncoder getPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}
	DaoAuthenticationProvider customProvider(){
		DaoAuthenticationProvider dao = new DaoAuthenticationProvider(); 
		//password Encoder info 
		dao.setPasswordEncoder(getPasswordEncoder());
		//give DB info
		dao.setUserDetailsService(myUserDetailsService);
		
		
		return dao;
	}

}
