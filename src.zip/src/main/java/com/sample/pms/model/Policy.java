package com.sample.pms.model;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.sample.pms.enums.PolicyTypeEnum;

@Entity
public class Policy {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Enumerated(EnumType.STRING)
	private PolicyTypeEnum type;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public PolicyTypeEnum getType() {
		return type;
	}
	public void setType(PolicyTypeEnum type) {
		this.type = type;
	}
	


}
