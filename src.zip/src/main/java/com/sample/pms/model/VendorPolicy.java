package com.sample.pms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class VendorPolicy {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long vendorPolicyId;
	@OneToOne
	private Vendor vendor;
	@OneToOne
	private Policy policy;
	
	private double idv;
	private double premium;
	
	
	public double getIdv() {
		return idv;
	}
	public void setIdv(double idv) {
		this.idv = idv;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	public Long getVendorPolicyId() {
		return vendorPolicyId;
	}
	public void setVendorPolicyId(Long vendorPolicyId) {
		this.vendorPolicyId = vendorPolicyId;
	}
	public Vendor getVendor() {
		return vendor;
	}
	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	public Policy getPolicy() {
		return policy;
	}
	public void setPolicy(Policy policy) {
		this.policy = policy;
	}
	
	
}
