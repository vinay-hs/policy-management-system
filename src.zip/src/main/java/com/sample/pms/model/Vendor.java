package com.sample.pms.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.sample.pms.enums.VendorAccessStatusEnum;
import com.sample.pms.enums.VendorNameEnum;

@Entity
public class Vendor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Enumerated(EnumType.STRING)
	private VendorAccessStatusEnum accessType;
	
	//@Enumerated(EnumType.STRING)
	private String vendorName;
	private LocalDate createdAt;
	private double rate;
	private double depriciation;
	

	public double getDepriciation() {
		return depriciation;
	}

	public void setDepriciation(double depriciation) {
		this.depriciation = depriciation;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	@OneToOne
	private User user;
	@ManyToOne
	private Admin admin;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	public LocalDate getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDate createdAt) {
		this.createdAt = createdAt;
	}

	public VendorAccessStatusEnum getAccessType() {
		return accessType;
	}

	public void setAccessType(VendorAccessStatusEnum accessType) {
		this.accessType = accessType;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "Vendor [id=" + id + ", accessType=" + accessType + ", vendorName=" + vendorName + ", createdAt="
				+ createdAt + ", user=" + user + ", admin=" + admin + "]";
	}

	

	

}