package com.sample.pms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.pms.model.Policy;

public interface PolicyRepository extends JpaRepository<Policy, Long>{

}
