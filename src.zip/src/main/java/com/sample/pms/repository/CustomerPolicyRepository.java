package com.sample.pms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.pms.model.CustomerPolicy;

public interface CustomerPolicyRepository extends JpaRepository<CustomerPolicy, Long>{

}
