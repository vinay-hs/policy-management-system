package com.sample.pms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sample.pms.model.MotorDetails;

public interface MotorDetailsRepository extends JpaRepository<MotorDetails, Long>{

	@Query("select mi from MotorDetails mi where mi.registrationNo=?1")
	Optional<MotorDetails> findByRegistartionNo(String registrationNo);
	

}
