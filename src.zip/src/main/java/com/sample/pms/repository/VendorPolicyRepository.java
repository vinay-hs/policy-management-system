package com.sample.pms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sample.pms.model.VendorPolicy;

public interface VendorPolicyRepository extends JpaRepository<VendorPolicy, Long>{

	@Query("select vp from VendorPolicy vp where vp.policy.type=?1")
	List<VendorPolicy> findByType(String policyType);
//
//	@Modifying
//	@Query(value="update VENDORPOLICY SET IDV =:idv")
//	public void save1(@Param("idv")double idv);
//
//	void saveAll(double idv);
	

}
