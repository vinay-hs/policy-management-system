package com.sample.pms.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.pms.dto.CustomerPolicyResponseDto;
import com.sample.pms.dto.VendorPolicyResponseDto;
import com.sample.pms.dto.VendorResponseDto;
import com.sample.pms.enums.VendorNameEnum;
import com.sample.pms.model.Customer;
import com.sample.pms.model.CustomerPolicy;
import com.sample.pms.model.MotorDetails;
import com.sample.pms.model.Policy;
import com.sample.pms.model.Vendor;
import com.sample.pms.model.VendorPolicy;

import com.sample.pms.repository.MotorDetailsRepository;
import com.sample.pms.repository.PolicyRepository;
import com.sample.pms.repository.VendorPolicyRepository;
import com.sample.pms.repository.VendorRepository;


@RestController
@RequestMapping("/api/vendorPolicy")
public class VendorPolicyController {
    @Autowired
    private VendorPolicyRepository vendorPolicyRepository;
    @Autowired
    private VendorRepository vendorRepository;
    @Autowired
    private PolicyRepository policyRepository;
    
    @Autowired
    private MotorDetailsRepository motorDetailsRepository;
    
    
    @PostMapping("add/{vendorId}/{policyId}")
    public ResponseEntity<String> addVendorPolicy(@RequestBody VendorPolicy vendorPolicy,
            @PathVariable("vendorId") Long vendorId, @PathVariable("policyId") Long policyId) {
        Optional<Vendor> optional = vendorRepository.findById(vendorId);
        if (!optional.isPresent())
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid vendor");
        Vendor vendor = optional.get();
        vendorPolicy.setVendor(vendor);

        Optional<Policy> optionalp = policyRepository.findById(policyId);
        if (!optionalp.isPresent())
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid policy");
        Policy policy = optionalp.get();
        vendorPolicy.setPolicy(policy);
        vendorPolicyRepository.save(vendorPolicy);
        return ResponseEntity.status(HttpStatus.OK).body("vendor Policy Added");
    }
    @GetMapping("/all")
    public List<VendorPolicyResponseDto> listAllVednorPolicy() throws Exception {
        List<VendorPolicy> list =  vendorPolicyRepository.findAll();
        List<VendorPolicyResponseDto>listDto=new ArrayList<>();
        
        for(VendorPolicy v:list) {
            Vendor vendor = v.getVendor();
            Policy policy =v.getPolicy();
            VendorPolicyResponseDto dto = new VendorPolicyResponseDto();
            dto.setId(v.getVendorPolicyId());
            dto.setPolicyType(policy.getType().toString());
            dto.setVendorName(vendor.getVendorName().toString());
            listDto.add(dto);
        }
        return listDto;
    }
    
    @PostMapping("addpolicy/{vid}/{mid}")
    public ResponseEntity<String> addDetails(@PathVariable("vid")Long vendorId,
                         @PathVariable("mid") Long motorId)
    {
        VendorPolicy vendorPolicy=new VendorPolicy();
        Optional<Vendor> optional = vendorRepository.findById(vendorId);
        if (!optional.isPresent())
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid vendor");
        Vendor vendor = optional.get();
        vendorPolicy.setVendor(vendor);
  
        Policy policy = new Policy();
        vendorPolicyRepository.save(vendorPolicy);
        
        Optional<MotorDetails> optionalm = motorDetailsRepository.findById(motorId);
        MotorDetails motorDetails=optionalm.get();
        policy.setId(motorDetails.getPolicy().getId());
        vendorPolicy.setPolicy(policy);
        double Idv=0;
        
        double premium=0;
        
        double soldAmount = motorDetails.getVehiclePrice();
        LocalDate boughtD = motorDetails.getYear();
        long year = ChronoUnit.YEARS.between(boughtD, LocalDate.now());
        double rate1=vendor.getRate();
        String vendorName = vendor.getVendorName();
        double depriciation=vendor.getDepriciation();       //rate =below 10
        //depriciation =above25
            if (year <= 1) {
                depriciation = depriciation;
                
                Idv = soldAmount - (depriciation * (soldAmount) / 100);
                premium = (Idv / 100) * rate1;
            
            } else if (year > 1 && year <= 2) {
                depriciation = depriciation+5.2;
                rate1 = rate1-2;
                Idv = soldAmount - (depriciation * (soldAmount) / 100);
                premium = (Idv / 100) * rate1;
        

            } else if (year > 2 && year <= 3) {
                depriciation = depriciation+10.4;
                rate1 = rate1-3.5;
                Idv = soldAmount - (depriciation * (soldAmount) / 100);
                premium = (Idv / 100) * rate1;
        
                
            } else if (year > 3 && year <= 4) {
                depriciation = depriciation+15.3;
                rate1 = rate1-4.6;
                Idv = soldAmount - (depriciation * (soldAmount) / 100);
                premium = (Idv / 100) * rate1;
            
                
            } else if (year > 4 && year <= 5) {
                depriciation = depriciation+20.6;
                rate1 =rate1- 5.9;
                Idv = soldAmount - (depriciation * (soldAmount) / 100);
                premium = (Idv / 100) * rate1;
            
                
            } else {
                depriciation = depriciation+25.9;
                rate1 = rate1-5.5;
                Idv = soldAmount - (depriciation * (soldAmount) / 100);
                premium = (Idv / 100) * rate1;
                
                
            }
        
//        if (vendorName.equals(VendorNameEnum.MSCHOLA)) {
//            if (year <= 1) {
//                depriciation = 10;
//                rate = 20;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//            
//            } else if (year > 1 && year <= 2) {
//                depriciation =20 ;
//                rate = 15;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//        
//
//            } else if (year > 2 && year <= 3) {
//                depriciation = 30;
//                rate = 12;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//        
//                
//            } else if (year > 3 && year <= 4) {
//                depriciation = 40;
//                rate = 8;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//            
//                
//            } else if (year > 4 && year <= 5) {
//                depriciation = 45;
//                rate = 5;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//            
//                
//            } else {
//                depriciation = 50;
//                rate = 2;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//                
//                
//            }
//        }
//        if (vendorName.equals(VendorNameEnum.ICICI)) {
//            if (year <= 1) {
//                depriciation = 13;
//                rate = 27;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//            
//            } else if (year > 1 && year <= 2) {
//                depriciation =24;
//                rate = 23;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//        
//
//            } else if (year > 2 && year <= 3) {
//                depriciation = 36;
//                rate = 17;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//        
//                
//            } else if (year > 3 && year <= 4) {
//                depriciation = 42;
//                rate = 15;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//            
//                
//            } else if (year > 4 && year <= 5) {
//                depriciation = 50;
//                rate = 10;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//            
//                
//            } else {
//                depriciation = 58;
//                rate = 7;
//                Idv = soldAmount - (depriciation * (soldAmount) / 100);
//                premium = (Idv / 100) * rate;
//                
//                
//            }
//        }
        vendorPolicy.setIdv(Idv);
        vendorPolicy.setPremium(premium);
        vendorPolicyRepository.save(vendorPolicy);
        return ResponseEntity.status(HttpStatus.OK).body("vendor Policy Added");
    }
    
    

}