package com.sample.pms.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.pms.dto.AdminResponseDto;
import com.sample.pms.dto.VendorResponseDto;
import com.sample.pms.enums.VendorAccessStatusEnum;
import com.sample.pms.model.Admin;
import com.sample.pms.model.User;
import com.sample.pms.model.Vendor;
import com.sample.pms.repository.AdminRepository;
import com.sample.pms.repository.UserRepository;
import com.sample.pms.repository.VendorRepository;

@RestController
@RequestMapping("/api/vendor")
public class VendorController {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private VendorRepository vendorRepository;
	@PostMapping("/add/{id}")
	public ResponseEntity<String> addVendor(@PathVariable("id")Long adminId,@RequestBody Vendor vendor){
		Optional<Admin> optional=adminRepository.findById(adminId);
		if(!optional.isPresent())
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("admin Id is invalid");
		Admin admin=optional.get();
		vendor.setAdmin(admin);
		vendor.setCreatedAt(LocalDate.now());
		User user=vendor.getUser();
		user.setRole("Vendor");
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user=userRepository.save(user);
		vendor.setUser(user);
		vendor.setAccessType(VendorAccessStatusEnum.PENDING);
		vendorRepository.save(vendor);
		return ResponseEntity.status(HttpStatus.OK).body("Vendor Sign up Successful");
	}
	@PutMapping("/status/{status}/{id}")
	public ResponseEntity<String> VendorAccessStatusUpdate(@PathVariable("status") String status,
															@PathVariable("id")Long vid){
		VendorAccessStatusEnum accessStatus=null;
		try {
			accessStatus=VendorAccessStatusEnum.valueOf(status);
		}
		catch(Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unknown Status");
		}
		Optional<Vendor> optional=vendorRepository.findById(vid);
		if(!optional.isPresent())
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vendor Id  is Invalid");
		Vendor vendor=optional.get();
		vendor.setAccessType(accessStatus);
		vendorRepository.save(vendor);
		return ResponseEntity.status(HttpStatus.OK).body("Vendor status updated");
	}
	@GetMapping("/all")
	public List<VendorResponseDto>getAllVendors(){
		List<Vendor>list=vendorRepository.findAll();
		List<VendorResponseDto>listDto=new ArrayList<>();
		for(Vendor v:list) {
//			VendorResponseDto dto = new VendorResponseDto();
//			dto.setId(a.getId());
//			dto.setName(a.getName());
//			listDto.add(dto);
		}
		return listDto;
	}
}
