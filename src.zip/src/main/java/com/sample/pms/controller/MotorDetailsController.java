package com.sample.pms.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.pms.dto.CustomerPolicyResponseDto;
import com.sample.pms.dto.MotorDetailsDto;
import com.sample.pms.model.Customer;
import com.sample.pms.model.CustomerPolicy;
import com.sample.pms.model.MotorDetails;
import com.sample.pms.model.Policy;
import com.sample.pms.repository.CustomerRepository;
import com.sample.pms.repository.MotorDetailsRepository;
import com.sample.pms.repository.PolicyRepository;

@RestController
@RequestMapping("/api/motorDetails")
public class MotorDetailsController {

	@Autowired
	private MotorDetailsRepository motorDetailsRepository;

	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private PolicyRepository policyRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@PostMapping("/add/{id}")
	public ResponseEntity<String> addMotorDetails(Principal principal,@RequestBody MotorDetails motorDetails,
			@PathVariable("id") Long id) {
		String username = principal.getName();

		// fetch costumer details
		Customer customer = customerRepository.getCustomerByUsername(username);
		Optional<Policy> optional=policyRepository.findById(id);
		 if (!optional.isPresent())
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid vendor");
		 Policy policy=optional.get();
		 motorDetails.setPolicy(policy);
		// connect motor Details with the costumer applying for
		motorDetails.setCustomer(customer);
		 

		motorDetailsRepository.save(motorDetails);

		return ResponseEntity.status(HttpStatus.OK).body("Your Motor Details has been applied successfully!!");

	}
	@GetMapping("/all/{registrationNo}")
    public List<MotorDetailsDto> fetchMotorDetails(@PathVariable("registrationNo") String registrationNo) throws Exception {
        Optional<MotorDetails> list =  motorDetailsRepository.findByRegistartionNo(registrationNo);
		List<MotorDetailsDto>listDto=new ArrayList<>();
		
		
			MotorDetails m=list.get();
			Customer customer=m.getCustomer();
			MotorDetailsDto dto = new MotorDetailsDto();
			dto.setId(m.getId());
			dto.setCustomerName(customer.getFirstname());
			dto.setVehicleType(m.getVehicleType());
			dto.setVehiclePrice(m.getVehiclePrice());
			dto.setYear(m.getYear());
			listDto.add(dto);
			return listDto;
    }

}