package com.sample.pms.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.pms.dto.AdminResponseDto;
import com.sample.pms.dto.CustomerResponseDto;
import com.sample.pms.model.Admin;
import com.sample.pms.model.Customer;
import com.sample.pms.model.User;
import com.sample.pms.repository.AdminRepository;
import com.sample.pms.repository.CustomerRepository;
import com.sample.pms.repository.UserRepository;
@RestController
@RequestMapping("/api/customer")
@CrossOrigin(origins = {"http://localhost:1234"})

public class CustomerController {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@PostMapping("/add")
	public Customer postCustomer(@RequestBody Customer customer) {
		User user=customer.getUser();
		user.setRole("CUSTOMER");
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user=userRepository.save(user);
		customer.setUser(user);
		customer=customerRepository.save(customer);
		customer.getUser().setPassword("-------");
		return customer;
	}
	@GetMapping("/all")
	public CustomerResponseDto getAllCustomers(Principal principal){
		String username=principal.getName();
		Customer customer=customerRepository.getCustomerByUsername(username);
	
		
			CustomerResponseDto dto = new CustomerResponseDto();
			dto.setId(customer.getId());
			dto.setFirstName(customer.getFirstname());
			dto.setLastName(customer.getLastname());
			dto.setContactNo(customer.getContactno());
			dto.setDob(customer.getDob());
			dto.setAddress(customer.getAddress());
			dto.setPanNo(customer.getPanno());
			
	
		return dto;
	}
}
