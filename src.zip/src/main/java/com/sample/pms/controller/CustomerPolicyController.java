package com.sample.pms.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.pms.dto.CustomerPolicyResponseDto;
import com.sample.pms.dto.VendorPolicyResponseDto;
import com.sample.pms.model.Customer;
import com.sample.pms.model.CustomerPolicy;
import com.sample.pms.model.Policy;
import com.sample.pms.model.Vendor;
import com.sample.pms.model.VendorPolicy;
import com.sample.pms.repository.CustomerPolicyRepository;
import com.sample.pms.repository.CustomerRepository;
import com.sample.pms.repository.PolicyRepository;
import com.sample.pms.repository.VendorPolicyRepository;

@RestController
@RequestMapping("/api/customerPolicy")
public class CustomerPolicyController {
	@Autowired 
	private CustomerPolicyRepository customerPolicyRepository;
	@Autowired
	private PolicyRepository policyRepository;
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private VendorPolicyRepository vendorPolicyRepository;
	
	@PostMapping("add/{customerId}/{vendorPolicyId}")
	public Object addCustomerPolicy(@PathVariable("customerId") Long customerId,@PathVariable("vendorPolicyId") Long policyId)
	{
		CustomerPolicy customerPolicy=new CustomerPolicy();
		Optional<Customer> optional = customerRepository.findById(customerId);
		if (!optional.isPresent())
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid customer");
		Customer customer = optional.get();
		customerPolicy.setCustomer(customer);
		
		customerPolicy.setStartDate(LocalDate.now());
		customerPolicy.setEndDate(LocalDate.now().plusYears(1));
		
		String No="PMS"+new Random().nextLong();
		customerPolicy.setPolicyNo(No);
		Optional<VendorPolicy> optionalp = vendorPolicyRepository.findById(policyId);
		if (!optionalp.isPresent())
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("invalid policy");
		VendorPolicy vendorPolicy=optionalp.get();
		customerPolicy.setVendorPolicy(vendorPolicy);
		
		customerPolicyRepository.save(customerPolicy);
		return ResponseEntity.status(HttpStatus.OK).body("Customer Added Policy Successfully!");
	}
	/* Search for the policies by policyType*/
	@GetMapping("/all/{type}")
    public List<VendorPolicyResponseDto> listAllVednorPolicy(@PathVariable("type") String policyType) throws Exception {
        List<VendorPolicy> list =  vendorPolicyRepository.findByType(policyType);
		List<VendorPolicyResponseDto>listDto=new ArrayList<>();
		
		for(VendorPolicy v:list) {
			Vendor vendor = v.getVendor();
			
			VendorPolicyResponseDto dto = new VendorPolicyResponseDto();
			dto.setId(v.getVendorPolicyId());
			//dto.setPolicyType(policy.getType().toString());
			dto.setVendorName(vendor.getVendorName().toString());
			listDto.add(dto);
		}
		return listDto;
    }
//	/*Get all customers policy details*/
//	@GetMapping("/all") //vendorid
//    public List<CustomerPolicyResponseDto> listAllCustomerPolicy() throws Exception {
//        List<CustomerPolicy> list =  customerPolicyRepository.findAll();
//		List<CustomerPolicyResponseDto>listDto=new ArrayList<>();
//		
//		for(CustomerPolicy c:list) {
//		
//			Policy policy =c.getPolicy();
//			Customer customer=c.getCustomer();
//			CustomerPolicyResponseDto dto = new CustomerPolicyResponseDto();
//			dto.setCustomerPolicyId(c.getId());
//			dto.setFirstName(customer.getFirstName());
//			dto.setPolicyType(policy.getType());
//			dto.setVendorName(c.getVendorName());
//			dto.setStartDate(c.getStartDate());
//			dto.setEndDate(c.getEndDate());
//			dto.setPremium(c.getPremium());
//			dto.setAmmountAssured(c.getAmountAssured());
//			listDto.add(dto);
//		}
//		return listDto;
//    }
	
	
}
