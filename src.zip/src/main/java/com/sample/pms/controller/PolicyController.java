package com.sample.pms.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sample.pms.model.Policy;

import com.sample.pms.repository.PolicyRepository;

@RestController
@RequestMapping("/api/policy")
public class PolicyController {
	@Autowired
	private PolicyRepository policyRepository;

	@PostMapping("/add")
	public ResponseEntity<String> savePolicy(@RequestBody Policy policy) {
		policy=policyRepository.save(policy);
		return ResponseEntity.status(HttpStatus.OK).body("Policy added Successfully");
	}
	@GetMapping("/all")
	public List<Policy> listAllPolicy() throws Exception {
		List<Policy> policy = policyRepository.findAll();
		if (policy.size() == 0) {
			throw new Exception("Policy table empty");
		}
		return policy;
	}
	@DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deletePolicyById(@PathVariable("id") Long id) {
        policyRepository.deleteById(id);
        return ResponseEntity.status(HttpStatus.OK).body("Policy deleted Successfully");
        
    }
}
