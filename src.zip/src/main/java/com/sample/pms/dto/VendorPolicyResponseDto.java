package com.sample.pms.dto;

public class VendorPolicyResponseDto {
	private long id;
	private long coverAmount;
	private long minimumAge;
	private String vendorName;
	private String policyType;
	
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getCoverAmount() {
		return coverAmount;
	}
	public void setCoverAmount(long coverAmount) {
		this.coverAmount = coverAmount;
	}
	public long getMinimumAge() {
		return minimumAge;
	}
	public void setMinimumAge(long minimumAge) {
		this.minimumAge = minimumAge;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	
	
}
