package com.sample.pms.dto;

import com.sample.pms.model.Vendor;

public class VendorResponseDto {
	
	
}
