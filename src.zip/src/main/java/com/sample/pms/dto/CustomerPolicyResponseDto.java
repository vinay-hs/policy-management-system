package com.sample.pms.dto;

import java.time.LocalDate;

public class CustomerPolicyResponseDto {
	private Long customerPolicyId;
	private String firstName;
	private String policyType;
	private String vendorName;
	private LocalDate startDate;
	private LocalDate endDate;
	private Long premium;
	private Long ammountAssured;

	
	public Long getCustomerPolicyId() {
		return customerPolicyId;
	}
	public void setCustomerPolicyId(Long customerPolicyId) {
		this.customerPolicyId = customerPolicyId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public Long getPremium() {
		return premium;
	}
	public void setPremium(Long premium) {
		this.premium = premium;
	}
	public Long getAmmountAssured() {
		return ammountAssured;
	}
	public void setAmmountAssured(Long ammountAssured) {
		this.ammountAssured = ammountAssured;
	}
	
	
}
