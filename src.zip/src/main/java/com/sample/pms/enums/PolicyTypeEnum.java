package com.sample.pms.enums;

public enum PolicyTypeEnum {
	CAR,BIKE

}
