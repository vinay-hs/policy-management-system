package com.sample.pms.enums;

public enum VendorNameEnum {
//TATAAIG,MSCHOLA,ICICI
}
