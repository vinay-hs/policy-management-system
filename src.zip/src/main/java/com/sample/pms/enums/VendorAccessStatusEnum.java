package com.sample.pms.enums;

public enum VendorAccessStatusEnum {
	GRANTED,DENIED,PENDING
}
