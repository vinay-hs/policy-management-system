import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './core/navbar/navbar.component';
import { ComponentComponent } from './component/component.component';
import { BikeComponent } from './component/bike/bike.component';
import {HttpClientModule} from '@angular/common/http';

import { CarComponent } from './component/car/car.component';
import { HomePageComponent } from './component/home-page/home-page.component';
import { ClaimsComponent } from './component/claims/claims.component';
import { PoliciesComponent } from './component/policies/policies.component';
import { LoginInComponent } from './component/login-in/login-in.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { VendorCarComponent } from './component/vendor-car/vendor-car.component';
import { VendorBikeComponent } from './component/vendor-bike/vendor-bike.component';
import { CustomerPolicyDetailsComponent } from './component/customer-policy-details/customer-policy-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserDashboardComponent } from './component/user-dashboard/user-dashboard.component';
import { VendorSignupComponent } from './component/vendor-signup/vendor-signup.component';
import { CustomerComponent } from './component/customer/customer.component';
import { NewpolicyComponent } from './component/user-dashboard/newpolicy/newpolicy.component';
import { UserpolicyComponent } from './component/user-dashboard/userpolicy/userpolicy.component';
import { ProfiledetailsComponent } from './component/user-dashboard/profiledetails/profiledetails.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ComponentComponent,
    BikeComponent,
    CarComponent,
    HomePageComponent,
    ClaimsComponent,
    PoliciesComponent,
    LoginInComponent,
    SignUpComponent,
    VendorCarComponent,
    VendorBikeComponent,
    CustomerPolicyDetailsComponent,
    UserDashboardComponent,
    VendorSignupComponent,
    CustomerComponent,
    NewpolicyComponent,
    UserpolicyComponent,
    ProfiledetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
