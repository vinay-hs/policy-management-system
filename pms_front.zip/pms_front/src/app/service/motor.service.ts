import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Motor } from '../Model/motor.model';
import { Policy } from '../Model/policy.model';

@Injectable({
  providedIn: 'root'
})
export class MotorService {

  constructor(private http:HttpClient) { }
  bike(motor:Motor):Observable<any>{
    let header = {
      'Authorization' : 'Basic ' + localStorage.getItem('token')
    }
    return this.http.post(environment.serverUrl +'/motorDetails/add/8',motor,{headers:header});
  }
}
