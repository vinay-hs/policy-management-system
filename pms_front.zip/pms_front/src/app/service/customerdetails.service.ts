import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Customer } from '../Model/customer.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerdetailsService {

  constructor(private http:HttpClient) { }
  getcustomer(){
    let header = {
      'Authorization' : 'Basic ' + localStorage.getItem('token')
    }
    return this.http.get<Customer[]>(environment.serverUrl + '/customer/all',{headers:header})
  }
}
