import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Customer } from '../Model/customer.model';
import { User } from '../Model/user.model';
import { vendor } from '../Model/vendor.model';
@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

  msg$ = new BehaviorSubject('');
  policy$=new BehaviorSubject<User>({});
  
  constructor(private http:HttpClient) { }

  signup(customer:Customer):Observable<any>{
    return  this.http.post(environment.serverUrl +'/customer/add',customer);
  }
  login(token: string):Observable<User> {
    let header={
      'Authorization':'Basic '+token
    }
     return this.http.get<User>(environment.serverUrl +'/user/login',{headers:header});
  }
  vendorsignup(vendor:vendor):Observable<any>{
    return this.http.post(environment.serverUrl +'/vendor/add/10',vendor);
  }
}
