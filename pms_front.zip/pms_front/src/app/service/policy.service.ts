import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Policy } from '../Model/policy.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  policy$=new BehaviorSubject({});
  constructor(private http:HttpClient) { }
  getAllPolicies():Observable<Policy[]>{
    return this.http.get<Policy[]>(environment.serverUrl + '/policy/all')
  }

}
