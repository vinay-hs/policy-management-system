import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Policy } from 'src/app/Model/policy.model';
import { PolicyService } from 'src/app/service/policy.service';

@Component({
  selector: 'app-policies',
  templateUrl: './policies.component.html',
  styleUrls: ['./policies.component.css']
})
export class PoliciesComponent implements OnInit {
  policyList:Policy[];
  constructor(public router:Router, private policyservice:PolicyService) { }

  ngOnInit(): void {
    this.policyservice.getAllPolicies().subscribe({
      next:(data)=>{
        this.policyList=data;
        console.log(this.policyList);
      },
      error:(err)=>{}
    });
  }

}
