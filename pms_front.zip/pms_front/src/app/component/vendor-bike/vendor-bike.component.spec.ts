import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorBikeComponent } from './vendor-bike.component';

describe('VendorBikeComponent', () => {
  let component: VendorBikeComponent;
  let fixture: ComponentFixture<VendorBikeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VendorBikeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorBikeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
