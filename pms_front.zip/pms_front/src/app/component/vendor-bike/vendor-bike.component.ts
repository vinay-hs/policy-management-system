import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-vendor-bike',
  templateUrl: './vendor-bike.component.html',
  styleUrls: ['./vendor-bike.component.css']
})
export class VendorBikeComponent implements OnInit {
  vendorbikeForm:FormGroup

  constructor() { }

  ngOnInit(): void {
  }

}
