import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Model/customer.model';
import { AuthserviceService } from 'src/app/service/authservice.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
signupForm:FormGroup;
customer:Customer;
msg:string;
 constructor(public router:Router,private authService:AuthserviceService)
 {}
  ngOnInit(): void {
    this.signupForm=new FormGroup({
      firstname:new FormControl("",[Validators.required,Validators.pattern(/^[a-zA-Z ]+$/)]),
      lastname:new FormControl("",[Validators.required,Validators.pattern(/^[a-zA-Z ]+$/)]),
      dob:new FormControl("",[Validators.required]),
      address:new FormControl("",[Validators.required,Validators.pattern(/^[a-zA-Z ]+$/)]),
      contactno:new FormControl("",[Validators.required,Validators.pattern(/^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/)]),
      panno:new FormControl("",[Validators.required,Validators.pattern(/^[a-zA-Z0-9 ]+$/)]),
      username:new FormControl("",[Validators.required,Validators.pattern(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)]),
      password:new FormControl("",[Validators.required,Validators.minLength(5), Validators.maxLength(15), Validators.pattern(/^[a-zA-Z0-9@%_]+$/)]),
      repassword:new FormControl("", [Validators.required])

    });
   
  }
  

 UserSignIn(){
  // this.router.navigate(["SignIn"]);
  this.customer={
    firstname:this.signupForm.value.firstname,
    lastname:this.signupForm.value.lastname,
    dob:this.signupForm.value.dob,
    contactno:this.signupForm.value.contactno,
    address:this.signupForm.value.address,
    panno:this.signupForm.value.panno,
    user:{
      username:this.signupForm.value.username,
      password:this.signupForm.value.password,
    }

  };
  let repassword = this.signupForm.value.repassword;
if(! (this.signupForm.value.password == repassword) ){
  this.msg = 'Passwords do not match';
}
else{
  this.authService.signup(this.customer).subscribe({
next:(data)=>{
  this.authService.msg$.next('SignUp Success!!')
  this.router.navigateByUrl('SignIn')
},
error:(err)=>{}
  });
}
 }
}
