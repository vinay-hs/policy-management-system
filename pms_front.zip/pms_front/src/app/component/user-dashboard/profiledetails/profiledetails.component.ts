import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Model/customer.model';
import { CustomerdetailsService } from 'src/app/service/customerdetails.service';

@Component({
  selector: 'app-profiledetails',
  templateUrl: './profiledetails.component.html',
  styleUrls: ['./profiledetails.component.css']
})
export class ProfiledetailsComponent implements OnInit {
  Customerdetails:any;
  customer:Customer;
  constructor(private customerdetailsservice:CustomerdetailsService, private router:Router) { }

  ngOnInit(): void {
    this.customerdetailsservice.getcustomer().subscribe(res=>{
      this.Customerdetails=res;  
    })
  }

}
