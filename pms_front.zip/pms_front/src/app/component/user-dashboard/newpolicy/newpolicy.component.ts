import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Policy } from 'src/app/Model/policy.model';
import { AuthserviceService } from 'src/app/service/authservice.service';
import { PolicyService } from 'src/app/service/policy.service';

@Component({
  selector: 'app-newpolicy',
  templateUrl: './newpolicy.component.html',
  styleUrls: ['./newpolicy.component.css']
})
export class NewpolicyComponent implements OnInit {
  policyList:Policy[];
  policy:Policy;
  constructor(public router:Router, private policyservice:PolicyService,private authservice:AuthserviceService) { }

  ngOnInit(): void {
    this.policyservice.getAllPolicies().subscribe({
      next:(data)=>{
        this.policyList=data;
        console.log(this.policyList);
      },
      error:(err)=>{}
    });
  }
  bikeregistration(policy:Policy){
    this.policyservice.policy$.next(policy);
    this.router.navigateByUrl('BikeRegistration');
  }

}
