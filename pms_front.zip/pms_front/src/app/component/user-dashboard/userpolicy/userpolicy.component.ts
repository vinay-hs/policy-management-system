import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userpolicy',
  templateUrl: './userpolicy.component.html',
  styleUrls: ['./userpolicy.component.css']
})
export class UserpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
