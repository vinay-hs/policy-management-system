import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/Model/user.model';
import { AuthserviceService } from 'src/app/service/authservice.service';

@Component({
  selector: 'app-login-in',
  templateUrl: './login-in.component.html',
  styleUrls: ['./login-in.component.css']
})
export class LoginInComponent implements OnInit{
  loginForm:FormGroup;
  msg:string;
  user:User;
 constructor(public router:Router,private authService:AuthserviceService)
{}
  ngOnInit(): void {
  this.loginForm=new FormGroup({
    username:new FormControl(''),
    password:new FormControl('')
  });
  this.authService.msg$.subscribe({
    next: (data)=>{
      this.msg = data;
    }
  });
  }
  onLogin(){
    let username = this.loginForm.value.username;
    let password = this.loginForm.value.password;
    let token = window.btoa(username + ':' + password);
    this.authService.login(token).subscribe({
      next: (data)=>{
        this.user = data;
        localStorage.setItem("username",this.user.username);
         localStorage.setItem("role", this.user.role);
         localStorage.setItem("token",token);

         if(this.user.role=='CUSTOMER'){
          this.router.navigateByUrl('user-dashboard');
         }
         else
         if(this.user.role=='VENDOR'){
          this.router.navigateByUrl('');
         }
         else
         if(this.user.role=='ADMIN'){
          this.router.navigateByUrl('');
         }
  },
  error:(err)=>{
    this.msg='invalid credentials'
  }
    });
  }
  userSignUp(){
    this.router.navigateByUrl('SignUp')
  }
}
