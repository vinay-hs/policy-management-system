import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-car',
  templateUrl: './vendor-car.component.html',
  styleUrls: ['./vendor-car.component.css']
})
export class VendorCarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
