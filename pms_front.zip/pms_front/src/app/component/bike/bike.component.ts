import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Motor } from 'src/app/Model/motor.model';
import { Policy } from 'src/app/Model/policy.model';
import { MotorService } from 'src/app/service/motor.service';
import { PolicyService } from 'src/app/service/policy.service';

@Component({
  selector: 'app-bike',
  templateUrl: './bike.component.html',
  styleUrls: ['./bike.component.css']
})
export class BikeComponent implements OnInit {
bikedetails:FormGroup;
motor:Motor;
policyId:number;
policy:Policy
  constructor(private router:Router,private motorservice:MotorService, private policyservice:PolicyService) { }

  ngOnInit(): void {
    this.policyservice.policy$.subscribe({
      next:(data)=>{
        this.policy=data;
      }
    });
    this.bikedetails=new FormGroup({
      vehicleType:new FormControl(""),
      vehiclePrice:new FormControl(""),
      registrationNo:new FormControl(""),
      year:new FormControl("")
    });
  }
  onBikedetails(){
    this.motor={
      vehicleType:this.bikedetails.value.vehicleType,
      vehiclePrice:this.bikedetails.value.vehiclePrice,
      registrationNo:this.bikedetails.value.registrationNo,
      year:this.bikedetails.value.year,
      policyId:this.bikedetails.value.policyId
    }
    this.motorservice.bike(this.motor).subscribe({
      next:(data)=>{
        this.router.navigateByUrl('BikePolicies');
        console.log(data);
      }
    });
  }
  bikeVendorPolicies(){
    this.router.navigate(["BikePolicies"])
  }

}
