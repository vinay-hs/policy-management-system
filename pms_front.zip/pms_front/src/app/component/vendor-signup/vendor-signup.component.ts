import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { vendor } from 'src/app/Model/vendor.model';
import { AuthserviceService } from 'src/app/service/authservice.service';

@Component({
  selector: 'app-vendor-signup',
  templateUrl: './vendor-signup.component.html',
  styleUrls: ['./vendor-signup.component.css']
})
export class VendorSignupComponent implements OnInit {
VendorSignupForm:FormGroup;
vendor:vendor;
  msg: string;
  constructor(public router:Router,private authservice:AuthserviceService)
  {
  
  }
  // UserSignIn() {
  //   this.router.navigate(["SignIn"]);
  //   }
    

  ngOnInit(): void {
    this.VendorSignupForm=new FormGroup({
      vendorName:new FormControl(""),
      depreciation:new FormControl(""),
      rate:new FormControl(""),
      username:new FormControl("",[Validators.required,Validators.pattern(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)]),
      password:new FormControl("",[Validators.required,Validators.minLength(5), Validators.maxLength(15), Validators.pattern(/^[a-zA-Z0-9@%_]+$/)]),
      repassword:new FormControl("", [Validators.required])
    });
  }
  VendorSignIn(){
    this.vendor={
      vendorName:this.VendorSignupForm.value.vendorName,
      depreciation:this.VendorSignupForm.value.depreciation,
      rate:this.VendorSignupForm.value.rate,
      user:{
          username:this.VendorSignupForm.value.username,
          password:this.VendorSignupForm.value.password,
      }
    };
    let repassword = this.VendorSignupForm.value.repassword;
if(! (this.VendorSignupForm.value.password == repassword) ){
  this.msg = 'Passwords do not match';
  }
  else{
    this.authservice.vendorsignup(this.vendor).subscribe({
  next:(data)=>{
    console.log(data);
    // this.authservice.msg$.next('SignUp Success!!')
    // this.router.navigateByUrl('SignIn')
    
  },
  error:(err)=>{}
    });
  }

}
}

