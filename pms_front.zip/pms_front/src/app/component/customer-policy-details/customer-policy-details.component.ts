import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-policy-details',
  templateUrl: './customer-policy-details.component.html',
  styleUrls: ['./customer-policy-details.component.css']
})
export class CustomerPolicyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
