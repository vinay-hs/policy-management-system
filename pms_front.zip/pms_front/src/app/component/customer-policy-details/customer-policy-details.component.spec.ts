import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPolicyDetailsComponent } from './customer-policy-details.component';

describe('CustomerPolicyDetailsComponent', () => {
  let component: CustomerPolicyDetailsComponent;
  let fixture: ComponentFixture<CustomerPolicyDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerPolicyDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPolicyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
