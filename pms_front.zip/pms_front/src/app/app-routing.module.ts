import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BikeComponent } from './component/bike/bike.component';
import { CarComponent } from './component/car/car.component';
import { ClaimsComponent } from './component/claims/claims.component';
import { CustomerComponent } from './component/customer/customer.component';
import { HomePageComponent } from './component/home-page/home-page.component';
import { LoginInComponent } from './component/login-in/login-in.component';
import { PoliciesComponent } from './component/policies/policies.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { NewpolicyComponent } from './component/user-dashboard/newpolicy/newpolicy.component';
import { ProfiledetailsComponent } from './component/user-dashboard/profiledetails/profiledetails.component';
import { UserDashboardComponent } from './component/user-dashboard/user-dashboard.component';
import { UserpolicyComponent } from './component/user-dashboard/userpolicy/userpolicy.component';
import { VendorBikeComponent } from './component/vendor-bike/vendor-bike.component';
import { VendorCarComponent } from './component/vendor-car/vendor-car.component';
import { VendorSignupComponent } from './component/vendor-signup/vendor-signup.component';
import { NavbarComponent } from './core/navbar/navbar.component';
import { Customer } from './Model/customer.model';

const routes: Routes = [
  {path:"NavBar",component: NavbarComponent},
  {path:"",component:HomePageComponent},
  {path:"CarRegistration",component:CarComponent},
  {path:"BikeRegistration",component:BikeComponent},
  {path:"Claims",component:ClaimsComponent},
  {path:"Policies",component:PoliciesComponent},
  {path:"SignIn",component:LoginInComponent},
  {path:"SignUp",component:SignUpComponent},
  {path:"CarPolicies",component:VendorCarComponent},
  {path:"BikePolicies",component:VendorBikeComponent},
  {path:"VendorSignUp",component:VendorSignupComponent},
  {path:"user-dashboard",component:UserDashboardComponent,children:[
    {path:"applypolicy",component:NewpolicyComponent},
    {path:"userpolicy",component:UserpolicyComponent},
    {path:"userdetails",component:ProfiledetailsComponent}
  ]
}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
