import { User } from "./user.model";

export class Customer{
    firstname?:string;
    lastname?:string;
    dob?:string;
    address?:string;
    contactno?:string;
    panno?:string;
    user?:User;
}
