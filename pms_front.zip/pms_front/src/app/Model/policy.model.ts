
export class Policy {
 id?:number;
 type?:string;
}


