import { User } from "./user.model";

export class vendor{
    vendorName?: string;
    depreciation?: string;
    rate?: string;
    user?:User;
}