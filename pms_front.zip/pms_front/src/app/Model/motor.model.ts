
export class Motor{

    vehicleType?:string;
    vehiclePrice?:number;
    registrationNo?:string;
    year?:string;
    policyId?:number;

}